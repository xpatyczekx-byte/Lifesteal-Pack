KSIĘGA ODRODZENIA — resource pack (CIT Resewn)
================================================

WYMAGANIA
- Fabric + mod "CIT Resewn" (lub "CIT Resewn Continuation" na nowsze wersje MC)
  https://modrinth.com/mod/cit-resewn

JAK ZAINSTALOWAĆ
1. Spakuj CAŁĄ ZAWARTOŚĆ tego folderu (pack.mcmeta + folder assets/) do pliku .zip
   (sam pack.mcmeta musi być w głównym katalogu zipa, NIE w podfolderze).
2. Wrzuć ten .zip do folderu: .minecraft/resourcepacks/
3. W grze: Opcje -> Resource Packs -> włącz "Ksiega Odrodzenia".
4. Upewnij się, że CIT Resewn jest zainstalowany i aktywny (log gry powinien
   pokazać, że wczytał plik ksiega_odrodzenia.properties).

JAK NADAĆ TEKSTURĘ KSIĄŻCE
- Weź zwykłą książkę (book) lub written_book i nadaj jej w KOWADLE nazwę:
      Ksiega Odrodzenia
  (dokładnie tak jak w pliku .properties — wielkość liter i treść muszą się zgadzać;
  jeśli chcesz polskie znaki "Księga Odrodzenia", zmień linię nbt.display.Name
  w pliku .properties na dokładnie taki tekst, z polskimi znakami).
- Tekstura powinna podmienić się automatycznie, bez żadnej komendy.

GDZIE CO JEST
assets/minecraft/citresewn/cit/ksiega_odrodzenia.properties
    -> reguła CIT: dopasowuje przedmiot "book"/"written_book" po nazwie
assets/minecraft/citresewn/cit/ksiega_odrodzenia.png
    -> sama tekstura 16x16 (ta mroczna, "agresywna" wersja)
assets/minecraft/textures/item/ksiega_odrodzenia.png
    -> zapasowa kopia tekstury (przyda się, gdybyś kiedyś chciał/a
       zrobić to też przez custom_model_data / datapack zamiast CIT)

DOSTOSOWANIE
- Chcesz dopasować też inne przedmioty (np. enchanted_book)? W linii "items="
  w pliku .properties dopisz kolejne id oddzielone spacją, np.:
      items=book written_book enchanted_book
- Chcesz dopasowanie "zawiera tekst" zamiast dokładnej nazwy? Użyj:
      nbt.display.Name.regex=.*Ksiega Odrodzenia.*
  zamiast linii nbt.display.Name=...

UWAGA
CIT Resewn działa TYLKO u graczy, którzy mają zainstalowany ten mod (i widzą
Twój resource pack). Gracze bez moda zobaczą zwykłą teksturę książki/
zapisanej książki. Jeśli chcesz, żeby tekstura działała u KAŻDEGO (też bez
mniejszościowych modów), to trzeba przejść na podejście custom_model_data +
mały datapack — daj znać, dorobię to jako wariant zapasowy.

AKTUALIZACJA (nowe wersje MC 1.21.4+)
- Pliki w citresewn/cit/*.properties używają starego zapisu nbt.display.Name i nie działają
  w nowych wersjach bez CIT Resewn Continuation.
- Dodano wersję bez modów: assets/minecraft/items/book.json, writable_book.json,
  written_book.json i red_dye.json podmieniają teksturę po nazwie z kowadła
  ("Księga Odrodzenia" / "Serce"). Własne przedmioty (scythe, ban_hammer, curved_sword,
  ice_sword) daje się komendą, np.: /give @p stick[item_model="minecraft:scythe"]


POLACZONE PACZKI
================
Ten pack zawiera w jednym zipie:
- SerwerowyTXT (baza: CIT ksiegi/serce, ban hammer, kosa, miecze, crate)
- Low Fire (niski ogien)
- New Glowing Ores (swiecace rudy; tekstury *_e = emisyjne, ramki przez CTM)

Pliki nie nakladaja sie na siebie (sprawdzone), wiec nic sie nawzajem nie nadpisuje.
Swiecenie rud (_e) wymaga mody/shaderow z obsluga emissive (np. Continuity / EMF+ETF),
a ramki rud wymagaja CTM (np. Continuity). Bez nich rudy beda zwyklymi teksturami.
Do ksiegi/serca nadal potrzebny CIT Resewn (patrz wyzej).
