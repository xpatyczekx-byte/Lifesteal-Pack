KSIĘGA ODRODZENIA — resource pack (CIT Resewn)
================================================

WYMAGANIA
- Fabric + mod "CIT Resewn" (lub "CIT Resewn Continuation" na nowsze wersje MC)
  https://modrinth.com/mod/cit-resewn

JAK ZAINSTALOWAĆ
1. Spakuj CAŁĄ ZAWARTOŚĆ tego folderu (pack.mcmeta + folder assets/) do pliku .zip
   (sam pack.mcmeta musi być w głównym katalogu zipa, NIE w podfolderze).
2. Wrzuć ten .zip do folderu: .minecraft/resourcepacks/
3. W grze: Opcje -> Resource Packs -> włącz "Ksiega Odrodzenia".
4. Upewnij się, że CIT Resewn jest zainstalowany i aktywny (log gry powinien
   pokazać, że wczytał plik ksiega_odrodzenia.properties).

JAK NADAĆ TEKSTURĘ KSIĄŻCE
- Weź zwykłą książkę (book) lub written_book i nadaj jej w KOWADLE nazwę:
      Ksiega Odrodzenia
  (dokładnie tak jak w pliku .properties — wielkość liter i treść muszą się zgadzać;
  jeśli chcesz polskie znaki "Księga Odrodzenia", zmień linię nbt.display.Name
  w pliku .properties na dokładnie taki tekst, z polskimi znakami).
- Tekstura powinna podmienić się automatycznie, bez żadnej komendy.

GDZIE CO JEST
assets/minecraft/citresewn/cit/ksiega_odrodzenia.properties
    -> reguła CIT: dopasowuje przedmiot "book"/"written_book" po nazwie
assets/minecraft/citresewn/cit/ksiega_odrodzenia.png
    -> sama tekstura 16x16 (ta mroczna, "agresywna" wersja)
assets/minecraft/textures/item/ksiega_odrodzenia.png
    -> zapasowa kopia tekstury (przyda się, gdybyś kiedyś chciał/a
       zrobić to też przez custom_model_data / datapack zamiast CIT)

DOSTOSOWANIE
- Chcesz dopasować też inne przedmioty (np. enchanted_book)? W linii "items="
  w pliku .properties dopisz kolejne id oddzielone spacją, np.:
      items=book written_book enchanted_book
- Chcesz dopasowanie "zawiera tekst" zamiast dokładnej nazwy? Użyj:
      nbt.display.Name.regex=.*Ksiega Odrodzenia.*
  zamiast linii nbt.display.Name=...

UWAGA
CIT Resewn działa TYLKO u graczy, którzy mają zainstalowany ten mod (i widzą
Twój resource pack). Gracze bez moda zobaczą zwykłą teksturę książki/
zapisanej książki. Jeśli chcesz, żeby tekstura działała u KAŻDEGO (też bez
mniejszościowych modów), to trzeba przejść na podejście custom_model_data +
mały datapack — daj znać, dorobię to jako wariant zapasowy.
